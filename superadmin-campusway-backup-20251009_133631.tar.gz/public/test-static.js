// Static JavaScript test file
console.log("Static JS file loaded successfully!");
window.staticTest = "Static file works!";
