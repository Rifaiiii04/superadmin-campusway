export default function NoDepsTest() {
    return (
        <div>
            <h1>Super Simple Test</h1>
            <p>No dependencies, just plain React</p>
        </div>
    );
}
